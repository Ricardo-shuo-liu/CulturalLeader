# player_walk_1

- Category: characters
- Size: 64x64
- Colors used: 18
- Animation: frames
- Design notes: 旅人角色逐帧动画；颜色取自 InkGongbi48，硬边无抗锯齿。
- Variants: none
